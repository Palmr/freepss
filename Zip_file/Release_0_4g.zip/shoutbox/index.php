<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>Palmnet Shoutbox</title>
	<link href="design/style.css" rel="stylesheet" type="text/css" />
	<!-- Original design by PWnet | www.pwnet.org.uk | October 2006 -->
	<!-- Shoutbox by Palmnet | www.palmnet.me.uk | October 2006 -->
	<!-- Shoutbox version 0.4g -->
</head>

<body>
	<div id="page">
		<div id="header">
			<div id="text">
				<h1>Palmnet Shoutbox</h1>
			</div>
			<div id="menu">
					<a href="index.php">Refresh</a> | <a href="http://code.google.com/p/freepss/">Get your own</a>
			</div>
			<div id="content">
<?php include"post.php"; ?>
			</div>
		</div>
		<div id="footer">
			<img src="design/credits.jpg" alt="Palmnet &amp; PWnet" width="241" height="96" border="0" align="right" usemap="#Map" />
			<map name="Map" id="Map">
				<area shape="rect" coords="7,24,96,58" href="http://www.palmnet.me.uk" alt="Palmnet" title="Palmnet" />
				<area shape="rect" coords="112,16,174,65" href="http://www.pwnet.org.uk" alt="PWnet" title="PWnet" />
			</map>
			<p class="copy">&copy; 2006 Nick Palmer &amp; Phil Wylie. All rights reserved.</p>
		</div>
	</div>
</body>
</html>