<?php
	//Admin details
	$adminname = "Admin";
	$adminpassword = "+pass";
	
	//The location of the content file
	$contentfile = "content.txt";
	
	//Shoutbox options
	$rssitemcount = 25;
	$timestamps = false;
	
	//Position of the shoutbox area on the shoutbox
	$Xval = 8;
	$Yval = 35;
?>