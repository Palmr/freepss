<?php
	//Admin details
	$adminname = "Admin";
	$adminpassword = "+pass";
	
	//The location of the content file
	$contentfile = "content.txt";
	
	//Shoutbox options
	$rssitemcount = 25;
	$timestamps = false;
	
	//Shoutbox image options
	$shoutboximg = "design/background.jpg";
	$shoutboxbgimg = "design/shoutbox.jpg";
	$Xval = 8;
	$Yval = 35;
?>