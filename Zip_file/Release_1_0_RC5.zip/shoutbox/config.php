<?php
	//Admin details
	$adminname = "Admin";
	$adminpassword = "+pass";

	//The location of the content file
	$contentfile = "content.txt";

	//Shoutbox options
	$textcolour = "000000";
	$shadowcolour = "CCCCCC";
	$rssitemcount = 25;
	$timestamps = true;
	$shadow = true;

	//Shoutbox image options
	$shoutboximg = "design/background.jpg";
	$shoutboxbgimg = "design/shoutbox.jpg";
	$Xval = 9;
	$Yval = 35;
?>